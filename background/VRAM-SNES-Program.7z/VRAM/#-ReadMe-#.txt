== How to Compile ==
Example: to compile vram.asm 
At a command prompt, goto the source directory, and run the command:
wla vram

Enjoy,
 Bazz